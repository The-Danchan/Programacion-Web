// declaramos array
var pokemones = ["Chorizord", "Venusaurio", "Blastoso"];
// var i =  0;

// while
/* while(i<=2){
    console.log(pokemones[i]);
    i++;
} */



// do while
/* do{
   console.log (pokemones[i]);
   i++;
}while(i<=2); */



for (var i = 0; i<=2; i++){
    document.write(pokemones[i] + " yo te elijo mano <br>");
}