/* 
        Bucle for
        Determinado
        su sintacsis consta de 3 partes
        - variable
        - numero de interaciones
        - incrementación

*/

/* for(var i = 0; i<3; i++){
    console.log(i);
} */


// ciclo for decremental

for(var i = 10; i>0; i--){
    console.log (i);
}