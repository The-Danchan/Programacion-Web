/* 
        Ciclo while sirve para ejecutar un código de forma cíclica mientras su condición se cumpla
*/

/* 
        definimos variable i
*/


/* var i = 0;
var número = prompt("Elija número");



while(i <= número){
    // código que se ejecuta
    document.write("hey soy un ciclote enciclado 7u7 <br>");
    // sumamos unidad a i para que la condición deje de cumplirse cuando i valga 9
    // i = i+1;
    i++;
}
*/


// ciclo do while ejecuta un código al menos 1 vez y si se cumple la condición vueleve a iterarlo

var i=0;
número = prompt("elija número");

do {
    // código que se ejecuta
    document.write("Dan <br>")
    i++;
} while (i<número);

